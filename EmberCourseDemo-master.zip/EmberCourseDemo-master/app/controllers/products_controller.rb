class ProductsController < ApplicationController


  layout false

  def index
    render
  end
end