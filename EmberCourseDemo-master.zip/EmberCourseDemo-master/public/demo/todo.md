## Cart

* Make the "Add to Cart" button do something.
* Show the items in cart / total in cart in the header or application template

## Products

* Clean up the "All 6 Products" link in comparison to the Filtered product links. Is it possible to have these in the same group without highlighting the parent route?
* Add images for products


## Goals

* See what can be done to make it more themed. How is this a store for stolen goods?
