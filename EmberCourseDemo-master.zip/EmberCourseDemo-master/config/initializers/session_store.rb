# Be sure to restart your server when you modify this file.

EmberDemo::Application.config.session_store :cookie_store, key: '_EmberDemo_session'
