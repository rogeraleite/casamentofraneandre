# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
EmberDemo::Application.config.secret_key_base = '41718ed75ed1b9e405f2ef23c4fbf03e2b45c2f1f9658f088076dd9049d2e036a634971d374349668c33476a1da5de8f2c7b4f3463de055f7b50e4f3497ff685'
